# Spatial Plots

::: monet_plots.plots.spatial.SpatialPlot
::: monet_plots.plots.spatial_contour.SpatialContourPlot
::: monet_plots.plots.spatial_bias_scatter.SpatialBiasScatterPlot
::: monet_plots.plots.xarray_spatial.XarraySpatialPlot
