# Wind Plots

::: monet_plots.plots.wind_quiver.WindQuiverPlot
::: monet_plots.plots.wind_barbs.WindBarbsPlot
