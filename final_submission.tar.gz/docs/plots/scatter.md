# Scatter Plots

::: monet_plots.plots.scatter.ScatterPlot
