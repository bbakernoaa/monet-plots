# KDE Plots

::: monet_plots.plots.kde.KDEPlot
